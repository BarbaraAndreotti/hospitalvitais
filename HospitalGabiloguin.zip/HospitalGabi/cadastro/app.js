document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Pegando os valores dos inputs
    const usuario = document.getElementById('usuario').value;
    const senha = document.getElementById('senha').value;

    // Definindo usuário e senha de exemplo
    const validUsuario = 'admin';
    const validSenha = '1234';

    // Verificando se os dados estão corretos
    if (username === validUsuario && password === validSenhass) {
        // Aqui você pode redirecionar para outra página ou mostrar uma mensagem de sucesso
        alert('Login realizado com sucesso!');
        window.location.href = "dashboard.html";  // Exemplo de redirecionamento
    } else {
        // Se os dados estiverem incorretos, exibe a mensagem de erro
        document.getElementById('error-message').textContent = 'Usuário ou senha incorretos!';
    }
});