const { Sequelize } = require('sequelize')
const sequelize = require('sequelize')
const connection = require('./database')

const usuario = connection.define('usuario', {
    id:{
        type : sequelize.INTEGER,
        AutoIncremente : true,
        primaryKey : true,
        Allownull : false,
    },
    nome:{
        type : sequelize.STRING(100),
        Allownull : false,
        validate:{
            notEmpty: true //evita strings vazias
        }
    },
    email:{
        type: Sequelize.STRING(100),
        Allownull: false,
        unique: true,
        validate:{
            isEmail: true
        },
    },
    senha:{
        type: Sequelize.STRING(10),
        Allownull: false
    },
    dataCriacao:{
        type:sequelize.DATE,
        defaultValue: Sequelize.NOW //define automaticamente a data e hora atual
    }
});


usuario.sync({force: false}).then(() =>{console.log("tabela criada!")})
module.exports = usuario;